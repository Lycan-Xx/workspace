import React from 'react'

function Trade() {
  return (
	<div className='max-w-3xl mx-auto p-6 text-[6rem] text-gray-500'>
		Coming soon !!!
	</div>

  )
}

export default Trade

// import React from "react";

// const Trade = () => (
//   <div className="p-6">
//     <h2 className="text-2xl font-bold text-blue-600 mb-4">Trade</h2>
//     <p className="text-gray-700">This is the Trade section where you can manage your trades.</p>
//   </div>
// );

// export default Trade;
